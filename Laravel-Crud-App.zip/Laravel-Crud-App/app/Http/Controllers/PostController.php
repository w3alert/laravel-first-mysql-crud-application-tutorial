<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator,Redirect,Response;
use App\Post;

class PostController extends Controller
{  

    public function index()
    {  
       $data['posts'] = Post::paginate(10);
       return view('list', $data);
    }

    public function showForm()
    {
      return view('insert-form');
    }

    public function insertRecord(Request $request)
    {
        $data = request()->validate([
        'title' => 'required',
        'description' => 'required',
        ]);
       
        $check = Post::insert($data);
        return Redirect::to("show-form")->withSuccess('Great! Form successfully submit with validation.');
    }
    public function edit(Request $request, $id)
    {
       
        $data['post'] = Post::where('id', $id)->first();

        if(!$data['post']){
           return redirect('/list');
        }
        return view('edit', $data);
    }

    public function updateRecord(Request $request)
    {
        $data = request()->validate([
        'title' => 'required',
        'description' => 'required',
        ]);
       
        if(!$request->id){
           return redirect('/list');
        }

        $check = Post::where('id', $request->id)->update($data);
        return Redirect::to("list")->withSuccess('Great! Form data successfully updated');
    }    
    public function deleteRecord(Request $request, $id)
    {
       
        if(!$id){
           return redirect('/list');
        }

        $check = Post::where('id', $id)->delete();
        return Redirect::to("list")->withSuccess('Great! data successfully deleted');
    }

}