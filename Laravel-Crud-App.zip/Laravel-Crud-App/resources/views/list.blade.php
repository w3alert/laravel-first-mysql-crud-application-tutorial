<html>
   <head>
      <title>Laravel Retrieve Data from Database</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="csrf-token" content="{{ csrf_token() }}">
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
   </head>
   <body>
      <div class="container mt-5">
         <div class="row">
            <a href="{{ url('insert-form') }}" class="btn btn-success mb-2">Add</a> 
              <br>
            <div class="col-md-12">
                     
             <table class="table table-bordered" id="laravel_crud">
              <thead>
                 <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Created at</th>
                    <td colspan="2">Action</td>
                 </tr>
              </thead>
              <tbody>
                 @foreach($posts as $post)
                 <tr>
                    <td>{{ $post->id }}</td>
                    <td>{{ $post->title }}</td>
                    <td>{{ $post->description }}</td>
                    <td>{{ date('Y-m-d', strtotime($post->created_at)) }}</td>
                    <td><a href="{{  url('edit/'.$post->id) }}" class="btn btn-primary">Edit</a></td>
                    <td>
                    <form action="{{  url('delete/'.$post->id) }}" method="get">
                     {{ csrf_field() }}
                     <button class="btn btn-danger" type="submit">Delete</button>
                   </form>
                   </td>
                 </tr>
                 @endforeach
              </tbody>
             </table>
             {!! $posts->links() !!}
 
            </div>
         </div>
      </div>
   </body>
</html>