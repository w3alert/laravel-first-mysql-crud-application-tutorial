<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//retrive data and display list
Route::get('list','PostController@index');

//show insert form and store data into database
Route::get('show-form','PostController@showForm');
Route::post('insert-record','PostController@insertRecord');

//display and update data into database
Route::get('edit/{id?}','PostController@edit');
Route::post('update-record','PostController@updateRecord');

//display and update data into database
Route::get('delete/{id?}','PostController@deleteRecord');