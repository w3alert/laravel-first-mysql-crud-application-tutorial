<html>
   <head>
      <title>Laravel Retrieve Data from Database</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
   </head>
   <body>
      <div class="container mt-5">
         <div class="row">
            <a href="<?php echo e(url('insert-form')); ?>" class="btn btn-success mb-2">Add</a> 
              <br>
            <div class="col-md-12">
                     
             <table class="table table-bordered" id="laravel_crud">
              <thead>
                 <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Created at</th>
                    <td colspan="2">Action</td>
                 </tr>
              </thead>
              <tbody>
                 <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->description); ?></td>
                    <td><?php echo e(date('Y-m-d', strtotime($post->created_at))); ?></td>
                    <td><a href="<?php echo e(url('edit/'.$post->id)); ?>" class="btn btn-primary">Edit</a></td>
                    <td>
                    <form action="<?php echo e(url('delete/'.$post->id)); ?>" method="get">
                     <?php echo e(csrf_field()); ?>

                     <button class="btn btn-danger" type="submit">Delete</button>
                   </form>
                   </td>
                 </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
             </table>
             <?php echo $posts->links(); ?>

 
            </div>
         </div>
      </div>
   </body>
</html><?php /**PATH D:\xampp\htdocs\CrudApplication\resources\views/list.blade.php ENDPATH**/ ?>